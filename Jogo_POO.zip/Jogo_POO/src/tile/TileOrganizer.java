package tile;

import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;

import main.Screen;

public class TileOrganizer {
	
	Screen sc; // Referência à tela principal
	Tile[] tile; // Array de tiles
	int mapTileNum[][]; // Matriz que armazena os números dos tiles do mapa
	
	public TileOrganizer(Screen sc) {
		
		this.sc = sc;
		
		tile = new Tile[10]; //Quantidade máxima de tiles que podem ser usados, alterar conforme necessidade;
		
		mapTileNum = new int [sc.maxWorldCol][sc.maxWorldRow]; // Inicializa a matriz do mapa
		
		getTileImage();
		loadMap("/maps/world01.txt");
	}
	
	// Método para carregar as imagens dos tiles
	public void getTileImage() {
		
		try {
			
			// Carregando diferentes tipos de tiles, quantidade máxima definida acima em tile
			tile[0] = new Tile();
			tile[0].image = ImageIO.read(getClass().getResourceAsStream("/tiles/grass.png"));
			
			tile[1] = new Tile();
			tile[1].image = ImageIO.read(getClass().getResourceAsStream("/tiles/wall.png"));
			
			tile[2] = new Tile();
			tile[2].image = ImageIO.read(getClass().getResourceAsStream("/tiles/blank.png"));
			
			tile[3] = new Tile();
			tile[3].image = ImageIO.read(getClass().getResourceAsStream("/tiles/earth.png"));
			
			tile[4] = new Tile();
			tile[4].image = ImageIO.read(getClass().getResourceAsStream("/tiles/tree.png"));
			
			tile[5] = new Tile();
			tile[5].image = ImageIO.read(getClass().getResourceAsStream("/tiles/sand.png"));
			
		}catch(IOException e) {
			e.printStackTrace(); // Exibe erro caso ocorra problema ao carregar as imagens
		}
	}
	
	// Método para carregar o mapa a partir de um arquivo de texto
	public void loadMap(String mapPath) {
		try {
			
			InputStream is = getClass().getResourceAsStream(mapPath);
			
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			
			int col = 0;
			int row = 0;
			
			while(col < sc.maxWorldCol && row < sc.maxWorldRow) {	
				
				String line = br.readLine(); // Lê uma linha do arquivo
				
				while (col < sc.maxWorldCol) {
					
					String numbers[] = line.split(" "); // Divide a linha em números
					
					int num = Integer.parseInt(numbers[col]); // Converte a string em número inteiro
					
					mapTileNum[col][row] = num; // Armazena o número na matriz
					col++;
				}
				if(col == sc.maxWorldCol) {	// Se a linha foi completamente lida, passa para a próxima
					
					col = 0;
					row++;					
				}
			}
			br.close();
		}catch(Exception e) {
			e.printStackTrace(); // Exibe erro caso ocorra problema ao carregar o mapa
		}
	}
	
	// Método para desenhar os tiles na tela
	public void draw(Graphics2D g2) {
		
		int worldCol = 0;
		int worldRow= 0;
		
		
		while(worldCol < sc.maxWorldCol && worldRow < sc.maxWorldRow) {
			
			int tileNum = mapTileNum[worldCol][worldRow]; // Obtém o número do tile
			
			int worldX = worldCol * sc.tileSize;
			int worldY = worldRow * sc.tileSize;
			int screenX = worldX - sc.player.worldY + sc.player.screenX;
			int screenY = worldY - sc.player.worldY + sc.player.screenY;
			
			g2.drawImage(tile[tileNum].image, screenX, screenY, sc.tileSize, sc.tileSize, null); // Desenha a imagem do tile
			
			worldCol++;
		
			if (worldCol == sc.maxWorldCol) { // Move para a próxima linha ao atingir o limite de colunas
				worldCol = 0;
				
				worldRow++;
				
			}	
		}
	}
}